package com.eb.quizAppSpainsh.frament;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.view.menu.MenuBuilder;
import androidx.appcompat.widget.PopupMenu;
import androidx.fragment.app.Fragment;

import com.eb.quizAppSpainsh.ListOfQuestions.QuestionTask1;
import com.eb.quizAppSpainsh.LoginActivity;
import com.eb.quizAppSpainsh.QuizScreen;
import com.eb.quizAppSpainsh.R;
import com.eb.quizAppSpainsh.models.ModelQuestions;
import com.google.firebase.auth.FirebaseAuth;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;

public class QuizCategoriesFragment extends Fragment  implements PopupMenu.OnMenuItemClickListener {

    private ImageButton imgMenu;
    private FirebaseAuth mAuth;
    Button btnRandomQuestion,btnReviewWrongQuestion,btnQuestionByTopics,btnAllQuestions;
    TextView txtQuizName;
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.quiz_category_fragment, container, false);
        return view;
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        mAuth = FirebaseAuth.getInstance();

        imgMenu=view.findViewById(R.id.btn_menu);
        btnRandomQuestion=view.findViewById(R.id.btnPregontos);
        btnReviewWrongQuestion=view.findViewById(R.id.btnReiser);
        btnQuestionByTopics=view.findViewById(R.id.btnTomas);
        btnAllQuestions=view.findViewById(R.id.btnTodas);
        txtQuizName=view.findViewById(R.id.txt_quizName);

        popUpMenu();

        btnRandomQuestion.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(getContext(),QuizScreen.class);
                intent.putExtra("quizName",txtQuizName.getText().toString().trim());
                intent.putExtra("totalQuestions",25);
                startActivity(intent);
            }
        });

//        for (int i = 0; i< QuestionTask1.task1.size(); i++){
//            Toast.makeText(getContext(), QuestionTask1.task1.get(i).getQuestion(), Toast.LENGTH_SHORT).show();
//        }

    }

    public void popUpMenu(){

        imgMenu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                PopupMenu popup = new PopupMenu(getContext(), v);
                try {
                    Field[] fields = popup.getClass().getDeclaredFields();
                    for (Field field : fields) {
                        if ("mPopup".equals(field.getName())) {
                            field.setAccessible(true);
                            Object menuPopupHelper = field.get(popup);
                            Class<?> classPopupHelper = Class.forName(menuPopupHelper.getClass().getName());
                            Method setForceIcons = classPopupHelper.getMethod("setForceShowIcon", boolean.class);
                            setForceIcons.invoke(menuPopupHelper, true);
                            break;
                        }
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
                popup.setOnMenuItemClickListener(QuizCategoriesFragment.this);
                popup.inflate(R.menu.popup_menu);

                popup.show();
            }
        });
    }


    @Override
    public boolean onMenuItemClick(MenuItem item) {
        switch (item.getItemId()){
            case R.id.action_logout:
                logout();

                return true;
        }
        return true;
    }

   void logout(){
        mAuth.signOut();
        startActivity(new Intent(getContext(), LoginActivity.class));
        getActivity().finish();
   }

}
