package com.eb.quizAppSpainsh.models;

public class ModelMonthlyProgress {

    String month;
    int marks;

    public ModelMonthlyProgress(String month, int marks) {
        this.month = month;
        this.marks = marks;
    }

    public String getMonth() {
        return month;
    }

    public void setMonth(String month) {
        this.month = month;
    }

    public int getMarks() {
        return marks;
    }

    public void setMarks(int marks) {
        this.marks = marks;
    }
}
