package com.eb.quizAppSpainsh;

import androidx.appcompat.app.AppCompatActivity;
import androidx.room.Room;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.eb.quizAppSpainsh.ListOfQuestions.QuestionTask1;
import com.eb.quizAppSpainsh.RoomDatabase.QuestionDatabase;
import com.eb.quizAppSpainsh.RoomDatabase.Questions;

import java.io.Serializable;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Random;

public class QuizScreen extends AppCompatActivity implements View.OnClickListener {

    TextView txtQuizName, txtQuizCount, txtQuizQuestion;
    Button btnOpt1, btnOpt2, btnOpt3;
    String answer;
    String quizName;
    String question, option1, option2, option3;
    List<Integer> questionsListGenerate = new ArrayList<Integer>();
    int number2;
    int randomIndex = 0;
    int correctQuestions = 0;
    int wrongQuestion = 0;
    int totalQuestions;
    QuestionTask1 questionTask1;
    QuestionDatabase questionsdb;
    String todayString;

    Map<String, String> mapWrongQuestions = new HashMap<String, String>();

    private void setupDB() {
        questionsdb = Room.databaseBuilder(this, QuestionDatabase.class, "QuizData")
                .allowMainThreadQueries().build();

    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_quiz_screen);
        questionTask1 = new QuestionTask1();
        quizName = getIntent().getStringExtra("quizName");
        totalQuestions=getIntent().getIntExtra("totalQuestions",0);
        txtQuizName = findViewById(R.id.txt_quizName);
        txtQuizName.setText(quizName);
        txtQuizCount = findViewById(R.id.txt_quizCounts);
        txtQuizQuestion = findViewById(R.id.txt_quiz_question);
        btnOpt1 = findViewById(R.id.btnOpt1);
        btnOpt1.setOnClickListener(this);
        btnOpt2 = findViewById(R.id.btnOpt2);
        btnOpt2.setOnClickListener(this);
        btnOpt3 = findViewById(R.id.btnOpt3);
        btnOpt3.setOnClickListener(this);

        setupDB();
        getMonth();
        generateRandom();
        showQuestions();


    }

    public void btnBack(View view) {
        finish();
    }

    void generateRandom() {

        number2 = QuestionTask1.task1.size();
        int[] number = new int[25];
        int count = 0;
        int num;
        Random r = new Random();
        while (count < number.length) {
            num = r.nextInt(number2);
            boolean repeat = false;
            do {
                for (int i = 0; i < number.length; i++) {
                    if (num == number[i]) {
                        repeat = true;
                        break;
                    } else if (i == count) {
                        number[count] = num;
                        count++;
                        repeat = true;
                        break;
                    }
                }
            } while (!repeat);

        }

        for (int j = 0; j < number.length; j++) {
            System.out.print(number[j]);
            int genNum = number[j];
            questionsListGenerate.add(genNum);

        }


    }

    void showQuestions() {
        if (randomIndex >= 25) {
            Intent intent=new Intent(QuizScreen.this,QuizResultScreen.class);
            intent.putExtra("totalQuestion",totalQuestions);
            intent.putExtra("correct",correctQuestions);
            intent.putExtra("wrong",wrongQuestion);
            intent.putExtra("hashMapWrongQues", (Serializable) mapWrongQuestions);
            intent.putExtra("quizName",quizName);
            startActivity(intent);
            finish();
            return;
        }
        int qNo = questionsListGenerate.get(randomIndex);
        txtQuizCount.setText("Pregurtas " + (randomIndex + 1) +"/"+ String.valueOf(totalQuestions));
        Log.e("randoms", String.valueOf(qNo));
        question = QuestionTask1.task1.get(qNo).getQuestion();
        answer = QuestionTask1.task1.get(qNo).getAnswer();
        option1 = QuestionTask1.task1.get(qNo).getOpt1();
        option2 = QuestionTask1.task1.get(qNo).getOpt2();
        option3 = QuestionTask1.task1.get(qNo).getOpt3();
        txtQuizQuestion.setText(question);
        btnOpt1.setText(option1);
        btnOpt2.setText(option2);
        btnOpt3.setText(option3);

    }

    @Override
    public void onClick(View v) {
        randomIndex += 1;
        switch (v.getId()) {
            case R.id.btnOpt1:

                String opt1 = btnOpt1.getText().toString();
                questionResult(opt1);
                break;
            case R.id.btnOpt2:
                String opt2 = btnOpt1.getText().toString();
                questionResult(opt2);
                break;
            case R.id.btnOpt3:
                String opt3 = btnOpt1.getText().toString();
                questionResult(opt3);
                break;


        }
        showQuestions();
    }

    void questionResult(String option) {
        if (option.equals(answer)) {
            correctQuestions++;

        } else {
            try {
                wrongQuestion++;
                mapWrongQuestions.put(question,answer);
                Questions modelquestions = new Questions(question, answer, option1, option2, option3);
                questionsdb.dao().questionInsertion(modelquestions);

            }catch (Exception e){
                 Log.v("",e.getMessage());
            }

        }
    }

    private  void getMonth(){
        Date todayDate = Calendar.getInstance().getTime();
        SimpleDateFormat formatter = new SimpleDateFormat("MMM/yyyy");
        todayString = formatter.format(todayDate);
    }

}