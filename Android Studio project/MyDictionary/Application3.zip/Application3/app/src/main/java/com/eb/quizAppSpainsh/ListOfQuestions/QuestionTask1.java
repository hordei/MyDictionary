package com.eb.quizAppSpainsh.ListOfQuestions;

import com.eb.quizAppSpainsh.models.ModelQuestions;

import java.util.ArrayList;

public class QuestionTask1 {

    public static ArrayList<ModelQuestions> task1;

    public QuestionTask1() {
        task1 = new ArrayList<>();

        task1.add(new ModelQuestions("La forma polÃ\u00ADtica del Estado espaÃ±ol es laâ€¦",
                "monarquÃ\u00ADa parlamentaria.",
                "monarquÃ\u00ADa parlamentaria.",
                "repÃºblica federal.",
                "monarquÃ\u00ADa federal."
        ));

        task1.add(new ModelQuestions("El actual Rey de EspaÃ±a esâ€¦",
                "Felipe VI",
                "Juan Carlos I.",
                "Felipe VI.",
                "Fernando VII."
        ));

        task1.add(new ModelQuestions("SegÃºn la ConstituciÃ³n espaÃ±ola, la soberanÃ\u00ADa nacional reside enâ€¦",
                "el pueblo espaÃ±ol.",
                "el pueblo espaÃ±ol.",
                "el Gobierno del Estado.",
                "el Congreso de los Diputados."
        ));

        task1.add(new ModelQuestions(
                "Â¿QuÃ© organismo tiene como misiÃ³n promocionar internacionalmente las empresas espaÃ±olas?",
                " ICEX.",
                "TurespaÃ±a.",
                "ICEX.",
                "Patrimonio Nacional."
        ));

        task1.add(new ModelQuestions(
                "La ConstituciÃ³n garantiza la libertad religiosa de los individuos y las comunidades, en este sentido, el Estado espaÃ±ol esâ€¦"
                , "aconfesional.",
                "laico.",
                "catÃ³lico.",
                "aconfesional."
        ));

        task1.add(new ModelQuestions(
                "La sede oficial del Rey de EspaÃ±a esâ€¦",
                "el Palacio Real.",
                "el Palacio Real.",
                "el Palacio de la Zarzuela.",
                "el Palacio de la Moncloa."
        ));

        task1.add(new ModelQuestions(
                "Â¿CuÃ¡l de estas fuerzas de seguridad es de Ã¡mbito autonÃ³mico?",
                "PolicÃ­a Foral de Navarra.",
                "PolicÃ­a local.",
                "Guardia Civil.",
                "PolicÃ­a Foral de Navarra."
        ));

        task1.add(new ModelQuestions(
                "Â¿CuÃ¡l de las siguientes fuerzas y cuerpos de seguridad es de Ã¡mbito nacional?",
                "La Guardia Civil.",
                "La PolicÃ­a Foral.",
                "La Guardia Civil.",
                "Los Mossos dâ€™Esquadra."
        ));

        task1.add(new ModelQuestions(
                "En la ConstituciÃ³n se establece la separaciÃ³n de poderes: el poder ejecutivo, el legislativo y elâ€¦",
                "judicial.",
                "judicial.",
                "informativo.",
                "polÃ­tico."

        ));

        task1.add(new ModelQuestions(
                " Durante el reinado deâ€¦ EspaÃ±a pasÃ³ a formar parte de la UniÃ³n Europea.",
                "Juan Carlos I",
                "Felipe VI",
                "Felipe II",
                "Juan Carlos I"
        ));


        task1.add(new ModelQuestions(
                "El organismo que gestiona los impuestos estatales de EspaÃ±a esâ€¦",
                "la Agencia Tributaria.",
                "El Consejo EconÃ³mico y Social.",
                "el Instituto Nacional de EstadÃ­stica.",
                "la Agencia Tributaria."

        ));


        task1.add(new ModelQuestions(
                "Las competencias en materia de sanidad estÃ¡n gestionadas porâ€¦",
                "las comunidades autÃ³nomas.",
                "el Estado.",
                "las comunidades autÃ³nomas.",
                "los ayuntamientos."
        ));

        task1.add(new ModelQuestions(
                "Las leyes que regulan los derechos fundamentales son las leyes",
                "orgÃ¡nicas.",
                "ordinarias.",
                "orgÃ¡nicas.",
                "de enjuiciamiento civil."
        ));

        task1.add(new ModelQuestions(
                "El Tribunal Constitucional es â€¦ de los poderes del Estado",
                "independiente",
                "dependiente",
                "independiente"
                , "subordinado"

        ));

        task1.add(new ModelQuestions(
                "El jefe del Estado esâ€¦",
                "el Rey.",
                "el presidente del Gobierno.",
                "el Rey.",
                "el ministro de Asuntos Exteriores, UniÃ³n Europea y CooperaciÃ³n."
        ));

        task1.add(new ModelQuestions(
                "Â¿QuiÃ©n modera el funcionamiento de las instituciones?",
                "El Rey.",
                "El presidente del Gobierno.",
                "El Rey."
                , "El juez de paz."
        ));

        task1.add(new ModelQuestions(
                "Lasâ€¦ ciudades autÃ³nomas de EspaÃ±a cuentan con un estatuto de autonomÃ­a",
                "2",
                "17",
                "2",
                "50"

        ));

        task1.add(new ModelQuestions(
                "Los poderes pÃºblicos aseguran la protecciÃ³n social, econÃ³mica yâ€¦ de la familia.",
                "jurÃ­dica"
                , "laboral",
                "jurÃ­dica"
                , "de integraciÃ³n"


        ));

        task1.add(new ModelQuestions(
                "Convocar elecciones corresponde alâ€¦",
                "Rey.",
                "ministro del Interior.",
                "presidente del Gobierno.",
                "Rey."

        ));

        task1.add(new ModelQuestions(
                "La mÃ¡s alta representaciÃ³n del Estado espaÃ±ol en las relaciones internacionales corresponde alâ€¦",
                "Rey.",
                "Rey.",
                "presidente del Gobierno.",
                "ministro de Asuntos Exteriores, UniÃ³n Europea y CooperaciÃ³n."

        ));

        task1.add(new ModelQuestions(
                "El presidente del Gobierno es nombrado por elâ€¦",
                "Rey.",
                "presidente del Congreso."
                , "Rey.",
                "defensor del Pueblo."


        ));

        task1.add(new ModelQuestions(
                " Â¿CÃ³mo se llaman los Ã³rganos de gobierno de Comunidad AutÃ³noma de las Islas Baleares",
                "Consejos insulares.",
                "Cabildos.",
                "Consejos insulares.",
                "Diputaciones."
        ));

        task1.add(new ModelQuestions(
                "Â¿CuÃ¡l es la tercera ciudad espaÃ±ola en nÃºmero de habitantes, despuÃ©s de Madrid y Barcelona?",
                "Valencia.",
                "Sevilla.",
                "Valencia.",
                "Bilbao."

        ));

        task1.add(new ModelQuestions(
                "Generalmente, se considera que el primer rey de EspaÃ±a fueâ€¦",
                "Carlos I.",
                "Carlos I.",
                "Fernando el Santo.",
                "Felipe II."
        ));

        task1.add(new ModelQuestions(
                "El Congreso de los Diputados y el Senado constituyen el poder",
                "legislativo.",
                "ejecutivo.",
                "legislativo.",
                "judicial."

        ));

        task1.add(new ModelQuestions(
                "Los colores de la bandera espaÃ±ola son",
                "rojo y amarillo.",
                "blanco y rojo.",
                "rojo y amarillo.",
                "amarillo y blanco."

        ));

        task1.add(new ModelQuestions(
                "Las comunidades autÃ³nomas deben utilizar, junto con la bandera de EspaÃ±a, sus propias banderas en",
                "sus edificios pÃºblicos y actos oficiales."
                , "sus edificios pÃºblicos.",
                "actos oficiales.",
                "sus edificios pÃºblicos y actos oficiales."

        ));

        task1.add(new ModelQuestions(
                "a bandera azul con 12 estrellas amarillas en cÃ­rculo es el sÃ­mbolo de",
                "la UniÃ³n Europea.",
                "la UniÃ³n Europea.",
                "la OrganizaciÃ³n de Seguridad y CooperaciÃ³n en Europa.",
                "la ComisiÃ³n de Europa."
        ));

        task1.add(new ModelQuestions(
                "Â¿CuÃ¡l de estas opciones es una lengua cooficial en alguna comunidad autÃ³noma",
                "El euskera.",
                "El bable.",
                "El aragonÃ©s.",
                "El euskera."

        ));

        task1.add(new ModelQuestions(
                "Todos los espaÃ±oles tienen el deber de conocer la lenguaâ€¦ del Estado",
                "oficial.",
                "autonÃ³mica.",
                "oficial.",
                "local."

        ));

        task1.add(new ModelQuestions(
                "Â¿CuÃ¡l de estas opciones es una lengua cooficial en alguna comunidad autÃ³noma",
                "El catalÃ¡n.",
                "El catalÃ¡n.",
                "El murciano.",
                "El asturleonÃ©s."
        ));

        task1.add(new ModelQuestions(
                "Las instituciones de una comunidad autÃ³noma son: la asamblea legislativa, el consejo de gobierno y",
                "el presidente.",
                "la diputaciÃ³n.",
                "el presidente.",
                "el delegado de gobierno."
        ));

        task1.add(new ModelQuestions(
                "Â¿CuÃ¡l de estas opciones es una lengua cooficial en alguna comunidad autÃ³noma",
                "El gallego.",
                "El gallego.",
                "El aragonÃ©s.",
                "El murciano."
        ));


        task1.add(new ModelQuestions(
                "Elâ€¦ tiene como fin la promociÃ³n y la enseÃ±anza del espaÃ±ol y las lenguas cooficiales, y tambiÃ©n la difusiÃ³n de la cultura en espaÃ±ol",
                "Instituto Nacional de EstadÃ­stica",
                "Instituto Nacional de AdministraciÃ³n PÃºblica",
                "Instituto Nacional de EstadÃ­stica",
                "Instituto Cervantes"

        ));


        task1.add(new ModelQuestions(
                "Â¿CuÃ¡l de los siguientes organismos trabaja para conseguir la normalizaciÃ³n lingÃ¼Ã­stica",
                "Real Academia EspaÃ±ola.",
                "Institut Ramon Llull.",
                "Instituto Cervantes.",
                "Real Academia EspaÃ±ola."
        ));

        task1.add(new ModelQuestions(
                "La sede de la Presidencia del Gobierno y residencia oficial del presidente es el",
                "Palacio de la Moncloa.",
                "Palacio Real.",
                "Palacio de la Zarzuela",
                "Palacio de la Moncloa."
        ));

        task1.add(new ModelQuestions(
                " Â¿CuÃ¡l de los siguientes cuerpos forma parte de las Fuerzas Armadas de EspaÃ±a",
                "El ejÃ©rcito del Aire.",
                "La PolicÃ­a Foral.",
                "La Guardia Civil.",
                "El ejÃ©rcito del Aire."

        ));

        task1.add(new ModelQuestions(

                "Â¿QuiÃ©nes forman parte del Gobierno",
                "Los ministros.",
                "Los ministros.",
                "Los concejales.",
                "Los alcaldes."

        ));

        task1.add(new ModelQuestions(
                "El poder ejecutivo corresponde",
                "al presidente del Gobierno y ministros.",
                "a los jueces y magistrados.",
                "al presidente del Gobierno y ministros.",
                "a los diputados y senadores."

        ));


        task1.add(new ModelQuestions(
                " Los proyectos de ley son aprobados por",
                "el Consejo de Ministros.",
                "el Consejo de Ministros.",
                "el presidente del Gobierno.",
                "el Congreso de los Diputados."

        ));

        task1.add(new ModelQuestions(
                "La administraciÃ³n civil de EspaÃ±a corresponde al poder",
                "ejecutivo.",
                "ejecutivo.",
                "legislativo.",
                "judicial."

        ));


        task1.add(new ModelQuestions(
                "Â¿CuÃ¡l de la siguientes instituciones simboliza la unidad de EspaÃ±a",
                "La Corona.",
                "La Corona.",
                "El Congreso de los Diputados.",
                "El Tribunal Supremo."

        ));

        task1.add(new ModelQuestions(
                "El gobierno responde en su gestiÃ³n polÃ­tica ante",
                "el Congreso de los Diputados.",
                "el Rey.",
                "el Senado.",
                "el Congreso de los Diputados."

        ));

        task1.add(new ModelQuestions(
                "El mando superior de las fuerzas y cuerpos de seguridad del Estado corresponde al",
                "ministro del Interior.",
                "ministro de Defensa.",
                "ministro del Interior.",
                "ministro de Justicia."

        ));

        task1.add(new ModelQuestions(
                " Â¿CuÃ¡ntas veces ha presidido EspaÃ±a el Consejo Europeo",
                "Cuatro veces.",
                "Dos veces.",
                "Tres veces.",
                "Cuatro veces."

        ));

        task1.add(new ModelQuestions(
                "Â¿CuÃ¡ntas veces ha reformado EspaÃ±a su ConstituciÃ³n para adaptarse a las decisiones y directivas europeas",
                "Dos veces.",
                "Ninguna.",
                "Una vez.",
                "Dos veces."
        ));


        task1.add(new ModelQuestions(
                " Â¿A cuÃ¡l de estas organizaciones internacionales pertenece EspaÃ±a",
                "A la OrganizaciÃ³n de las Naciones Unidas (ONU).",
                "Al Mercado ComÃºn del Sur (MERCOSUR).",
                "A la OrganizaciÃ³n de las Naciones Unidas (ONU).",
                "A la UniÃ³n EconÃ³mica EuroasiÃ¡tica (UEE)."

        ));

        task1.add(new ModelQuestions(
                "En la organizaciÃ³n de la AdministraciÃ³n General del Estado se distinguen tres niveles: estatal, autonÃ³mico y",
                "local.",
                "central.",
                "regional.",
                "local."

        ));

        task1.add(new ModelQuestions(
                "El poder legislativo corresponde",
                "a los diputados y senadores.",
                "al presidente y los ministros.",
                "a los jueces y magistrados.",
                "a los diputados y senadores."

        ));

        task1.add(new ModelQuestions(
                "El Senado estÃ¡ compuesto actualmente porâ€¦ senadores",
                "266",
                "352",
                "266",
                "198"

        ));


        task1.add(new ModelQuestions(
                "El nombre oficial del parlamento espaÃ±ol es",
                "Cortes Generales.",
                "Cortes Generales.",
                "Congreso de los Diputados.",
                "Senado."

        ));

        task1.add(new ModelQuestions(
                "El Rey y su familia viven en el",
                "Palacio de la Zarzuela.",
                "Palacio Real.",
                "Palacio de la Moncloa.",
                "Palacio de la Zarzuela."

        ));


        task1.add(new ModelQuestions(
                "La investidura del presidente del Congreso se realiza en",
                "el Congreso de los Diputados.",
                "el Palacio de la Moncloa.",
                "el Palacio de la Zarzuela.",
                "el Congreso de los Diputados."
        ));

        task1.add(new ModelQuestions(
                "Al poder legislativo le corresponde",
                "elaborar leyes.",
                "crear empleo.",
                "elaborar leyes.",
                "elegir alcaldes."

        ));


        task1.add(new ModelQuestions(
                "La tercera autoridad del Estado, tras el Rey y el presidente del Gobierno, es el",
                "presidente del Congreso de los Diputados.",
                "ministro del Interior.",
                "jefe del Estado Mayor del EjÃ©rcito.",
                "presidente del Congreso de los Diputados."

        ));

        task1.add(new ModelQuestions(
                "Â¿CuÃ¡ntos ciudadanos deben respaldar una iniciativa legislativa para poder presentar una proposiciÃ³n de ley",
                "500.000",
                "400.000",
                "500.000",
                "600.000"

        ));

        task1.add(new ModelQuestions(
                "La ConstituciÃ³n defiende valores tales como la libertad, â€¦, la igualdad y el pluralismo polÃ­tico",
                "la justicia",
                "la justicia",
                "la solidaridad",
                "la fraternidad"

        ));


        task1.add(new ModelQuestions(
                "La iniciativa legislativa presentada por el gobierno se llama",
                "proyecto de ley.",
                "ley orgÃ¡nica.",
                "proyecto de ley.",
                "proyecto de gobierno."

        ));

        task1.add(new ModelQuestions(
                "El nÃºmero de habitantes en EspaÃ±a es aproximadamente de",
                "47 millones.",
                "47 millones.",
                "35 millones.",
                "62 millones."

        ));

        task1.add(new ModelQuestions(
                "Â¿CuÃ¡l es el Ã³rgano supremo consultivo del Gobierno de EspaÃ±a",
                "El Consejo de Estado.",
                "El Parlamento Europeo.",
                "El Consejo de Estado.",
                "El Tribunal Constitucional."
        ));

        task1.add(new ModelQuestions(
                "Elâ€¦ dirige la polÃ­tica interior y exterior de EspaÃ±a",
                "Gobierno",
                "Rey",
                "Gobierno",
                "Senado"

        ));

        task1.add(new ModelQuestions(
                "Â¿CuÃ¡l es el tribunal encargado de interpretar la ConstituciÃ³n espaÃ±ola en relaciÃ³n a actuaciones de los poderes pÃºblicos",
                "El Tribunal Constitucional.",
                "El Tribunal Supremo.",
                "El Tribunal de Justicia de la UniÃ³n Europea.",
                "El Tribunal Constitucional."
        ));

        task1.add(new ModelQuestions(
                "El Instituto Etxepare tiene como misiÃ³n la difusiÃ³n del",
                "euskera y la cultura vasca.",
                "euskera y la cultura vasca.",
                "bable y la cultura cÃ¡ntabra.",
                "gallego y la cultura galaica."

        ));
        task1.add(new ModelQuestions(
                "La CÃ¡mara de representaciÃ³n territorial se llama",
                "Senado.",
                "Congreso de los Diputados.",
                "CÃ¡mara de Comercio.",
                "Senado."
        ));
        task1.add(new ModelQuestions(
                "Â¿CuÃ¡ntos senadores se eligen en cada provincia, con excepciÃ³n de las islas y las ciudades autÃ³nomas de Ceuta y Melilla",
                "4.",
                "3.",
                "4.",
                "5."
        ));

        task1.add(new ModelQuestions(
                "Las ciudades autÃ³nomas de Ceuta y Melilla eligen en las elecciones cada una de ellas a",
                "2 senadores.",
                "1 senador.",
                "2 senadores.",
                "3 senadores."

        ));


        task1.add(new ModelQuestions(
                "El Consejo General del Poder judicial estÃ¡ integrado por",
                "jueces y juristas.",
                "abogados y fiscales.",
                "polÃ­ticos y jueces.",
                "jueces y juristas."

        ));

        task1.add(new ModelQuestions(
                "El control de la acciÃ³n del Gobierno corresponde",
                "a las Cortes Generales.",
                "a las Cortes Generales.",
                "a la Junta Electoral Central.",
                "al Rey."

        ));

        task1.add(new ModelQuestions(
                "Â¿CuÃ¡l de estos organismos forma parte del poder judicial",
                "El Tribunal Supremo.",
                "El Tribunal de Cuentas.",
                "El Tribunal Constitucional.",
                "El Tribunal Supremo."

        ));

        task1.add(new ModelQuestions(
                "El Institut RamÃ³n Llull es un organismo de Ã¡mbitoâ€¦ para la difusiÃ³n de la lengua y la cultura catalana",
                "internacional",
                "autonÃ³mico",
                "nacional",
                "internacional"
        ));
        task1.add(new ModelQuestions(
                "Elâ€¦ es el encargado de la elaboraciÃ³n de leyes",
                "poder legislativo",
                "poder ejecutivo",
                "poder legislativo",
                "el defensor del pueblo."
        ));
        task1.add(new ModelQuestions(
                "La defensa de la integridad territorial de EspaÃ±a corresponde a",
                "las Fuerzas Armadas.",
                "la PolicÃ­a Nacional y la Guardia Civil.",
                "las Fuerzas Armadas.",
                "la PolicÃ­a Nacional y las policÃ­as autonÃ³micas."
        ));

        task1.add(new ModelQuestions(
                "El EjÃ©rcito espaÃ±ol participa desde 1989 en misiones de paz de la",
                "OrganizaciÃ³n de Naciones Unidas (ONU).",
                "OrganizaciÃ³n de Estados Iberoamericanos (OEI).",
                "UniÃ³n Europea Occidental (UEO).",
                "OrganizaciÃ³n de Naciones Unidas (ONU)."
        ));

        task1.add(new ModelQuestions(
                "La vigilancia de puertos y aeropuertos, fronteras y costas corresponde a",
                "la Guardia Civil.",
                "la Guardia Civil.",
                "la PolicÃ­a Local.",
                "la PolicÃ­a Nacional."

        ));

        task1.add(new ModelQuestions(
                "La regulaciÃ³n del trÃ¡fico en las ciudades corresponde a",
                "la PolicÃ­a Local.",
                "la Guardia Civil.",
                "la PolicÃ­a Local.",
                "la PolicÃ­a Nacional."

        ));

        task1.add(new ModelQuestions(
                "Â¿CÃ³mo se llama la policÃ­a autonÃ³mica de CataluÃ±a",
                "Mossos d'Esquadra.",
                "Guardia Civil.",
                "Ertzaintza.",
                "Mossos d'Esquadra."

        ));

        task1.add(new ModelQuestions(
                " Â¿CÃ³mo se llama la policÃ­a autonÃ³mica del PaÃ­s Vasco",
                "Ertzaintza.",
                "Ertzaintza.",
                "Guardia Civil.",
                "Mossos d'Esquadra."
        ));

        task1.add(new ModelQuestions(
                "Â¿Cada cuÃ¡ntos aÃ±os, como mÃ¡ximo, se convocan obligatoriamente elecciones generales al parlamento espaÃ±ol",
                "Cada 4 aÃ±os.",
                "Cada 3 aÃ±os.",
                "Cada 4 aÃ±os.",
                "Cada 5 aÃ±os."
        ));
        task1.add(new ModelQuestions(
                "El presidente del Gobierno de EspaÃ±a entre 1982 y 1996 fue",
                "Felipe GonzÃ¡lez.",
                "JosÃ© MarÃ­a Aznar.",
                "JosÃ© Luis RodrÃ­guez Zapatero.",
                "Felipe GonzÃ¡lez."

        ));

        task1.add(new ModelQuestions(
                "Â¿QuiÃ©n puede presentar una queja al Defensor del Pueblo",
                "Todos los ciudadanos, espaÃ±oles o extranjeros.",
                "Solo los ciudadanos legalmente residentes.",
                "Solo los espaÃ±oles mayores de 18 aÃ±os.",
                "Todos los ciudadanos, espaÃ±oles o extranjeros."

        ));
        task1.add(new ModelQuestions(
                "Â¿A quiÃ©n informa de su gestiÃ³n el Defensor del Pueblo",
                "A las Cortes Generales.",
                "Al Rey.",
                "Al presidente del Gobierno.",
                "A las Cortes Generales."

        ));

        task1.add(new ModelQuestions(
                "Â¿CuÃ¡l es el Ã³rgano que controla la gestiÃ³n econÃ³mico-financiera del Estado",
                "El Tribunal de Cuentas.",
                "El Tribunal de Cuentas.",
                "El Tribunal Supremo.",
                "El Tribunal Constitucional."

        ));
        task1.add(new ModelQuestions(
                "La inspecciÃ³n y recaudaciÃ³n de los impuestos que gestiona el Estado corresponde a",
                "la Agencia Tributaria.",
                "el Tribunal de Cuentas.",
                "la Agencia Tributaria.",
                "el Consejo EconÃ³mico y Social."
        ));
        task1.add(new ModelQuestions(
                "El organismo que elabora y difunde estadÃ­sticas sobre EspaÃ±a es",
                "el Instituto Nacional de EstadÃ­stica.",
                "el Consejo EconÃ³mico y Social.",
                "el Instituto Nacional de EstadÃ­stica.",
                "la Agencia Tributaria."
        ));
        task1.add(new ModelQuestions(
                "Â¿CÃ³mo se llaman los Ã³rganos de gobierno de la Comunidad AutÃ³noma de Canarias",
                " Cabildos.",
                "Cabildos.",
                " Consejos Insulares.",
                "Diputaciones."

        ));
        task1.add(new ModelQuestions(
                " El Gobierno ofrece toda la informaciÃ³n sobre novedades e iniciativas de la AdministraciÃ³n a travÃ©s del",
                "El PAE (Portal de AdministraciÃ³n ElectrÃ³nic.",
                "El INE (Instituto Nacional de EstadÃ­stic.",
                "El BOE (BoletÃ­n Oficial del Estado).",
                "El PAE (Portal de AdministraciÃ³n ElectrÃ³nic."
        ));
        task1.add(new ModelQuestions(
                "El telÃ©fono de la AdministraciÃ³n General del Estado que ofrece informaciÃ³n sobre empleo pÃºblico, becas o ayudas y subvenciones, organismos de las Administraciones, etc., es el",
                "060.",
                "010.",
                "060.",
                "091."
        ));

        task1.add(new ModelQuestions(
                "El Estado espaÃ±ol se organiza territorialmente en",
                "municipios, provincias y comunidades autÃ³nomas.",
                "municipios, cantones y regiones administrativas.",
                "municipios, provincias y comunidades autÃ³nomas.",
                "municipios, distritos y estados federales."
        ));

        task1.add(new ModelQuestions(
                "Las provincias limÃ­trofes con caracterÃ­sticas histÃ³ricas, culturales y econÃ³micas comunes, las islas y las provincias con especial entidad regional histÃ³rica fueron la base de",
                "las comunidades autÃ³nomas.",
                "las comunidades autÃ³nomas.",
                "los distritos.",
                "los municipios."

        ));

        task1.add(new ModelQuestions(
                "Las leyes orgÃ¡nicas normativas de las comunidades y ciudades autÃ³nomas de EspaÃ±a se denominan",
                "estatutos de autonomÃ­a.",
                "leyes de autonomÃ­a.",
                "estatutos de autonomÃ­a.",
                "reglamentos de autonomÃ­a."

        ));

        task1.add(new ModelQuestions(
                "El gobierno y la protecciÃ³n de las provincias corresponde a",
                "las diputaciones.",
                "las diputaciones.",
                "los ayuntamientos.",
                "las asambleas regionales."
        ));

        task1.add(new ModelQuestions(
                "Â¿QuiÃ©n es el representante de la AdministraciÃ³n del Estado en una comunidad autÃ³noma",
                "El delegado del Gobierno.",
                "El presidente de la comunidad autÃ³noma.",
                "El delegado del Gobierno.",
                "El presidente de la Asamblea autonÃ³mica."
        ));
        task1.add(new ModelQuestions(
                " Â¿CuÃ¡ntas provincias hay en EspaÃ±a",
                "50.",
                "49.",
                "50.",
                "52."
        ));

        task1.add(new ModelQuestions(
                "La enseÃ±anza de las lenguas cooficiales es competencia",
                "de la comunidad autÃ³noma.",
                "del Estado.",
                "de la comunidad autÃ³noma.",
                "de la provincia."
        ));

        task1.add(new ModelQuestions(
                "Â¿CÃ³mo se llama la norma extraordinaria que dicta el gobierno en circunstancias especiales y que tiene rango de ley",
                "Decreto ley.",
                "Ley orgÃ¡nica.",
                "Decreto ley.",
                "Reglamento."
        ));
        task1.add(new ModelQuestions(
                "Los concejales de los ayuntamientos son elegidos por",
                "los vecinos del municipio.",
                "los vecinos del municipio.",
                "los alcaldes.",
                "los representantes provinciales."
        ));
        task1.add(new ModelQuestions(
                "En urbanismo, la competencia es",
                "de los ayuntamientos.",
                "de los ayuntamientos.",
                "del Estado.",
                "de las comunidades autÃ³nomas."
        ));

        task1.add(new ModelQuestions(
                "En materia de nacionalidad, inmigraciÃ³n, emigraciÃ³n, extranjerÃ­a y derecho de asilo, la competencia exclusiva es",
                "del Estado.",
                "del Estado.",
                "de las comunidades autÃ³nomas.",
                "de los ayuntamientos."
        ));


        task1.add(new ModelQuestions(
                "El ayuntamiento estÃ¡ formado por el alcalde y",
                "los concejales.",
                "los concejales.",
                "los diputados.",
                "los senadores."
        ));

        task1.add(new ModelQuestions(
                "Â¿QuiÃ©nes forman parte del gobierno de las comunidades autÃ³nomas",
                "El presidente y los consejeros.",
                "El presidente y los ministros.",
                "El alcalde y los concejales.",
                "El presidente y los consejeros."
        ));
        task1.add(new ModelQuestions(
                "Â¿CuÃ¡l es el Ã³rgano de gobierno en los municipios",
                "El ayuntamiento.",
                "El ayuntamiento.",
                "La diputaciÃ³n.",
                "El cabildo."

        ));

        task1.add(new ModelQuestions(
                "Â¿CÃ³mo se llaman los Ã³rganos de gobierno de las provincias espaÃ±olas",
                "Diputaciones.",
                "Cabildos.",
                "Consejos Insulares.",
                "Diputaciones."
        ));
        task1.add(new ModelQuestions(
                "Â¿CuÃ¡l de estas tres ciudades espaÃ±olas estÃ¡ entre las diez mÃ¡s pobladas",
                "MÃ¡laga.",
                "MÃ¡laga.",
                "GijÃ³n.",
                "Toledo."
        ));
        task1.add(new ModelQuestions(
                "Los espaÃ±oles son mayores de edad a los",
                "18 aÃ±os.",
                "16 aÃ±os.",
                "18 aÃ±os.",
                "21 aÃ±os."
        ));

        task1.add(new ModelQuestions(
                "Â¿CuÃ¡l de estas ciudades ha sido alguna vez capital de EspaÃ±a",
                "Toledo.",
                "Barcelona.",
                "Toledo.",
                "Sevilla."

        ));
        task1.add(new ModelQuestions(
                "Los espaÃ±oles pueden votar a partir de los",
                "18 aÃ±os.",
                "16 aÃ±os.",
                "18 aÃ±os.",
                "21 aÃ±os."

        ));
        task1.add(new ModelQuestions(
                "Los ciudadanos de la UniÃ³n Europea y de algunos paÃ­ses con acuerdos de reciprocidad, residentes en EspaÃ±a, pueden votar en las elecciones",
                "locales.",
                "locales.",
                "autonÃ³micas.",
                "generales."
        ));

        task1.add(new ModelQuestions(
                "En EspaÃ±a, los cargos de presidente y vocales de las mesas electorales son",
                "obligatorios.",
                "obligatorios.",
                "voluntarios.",
                "permanentes."
        ));

        task1.add(new ModelQuestions(
                "Â¿A quiÃ©nes se elige en las elecciones generales.",
                "A los senadores y diputados.",
                "A los senadores y diputados.",
                "A los senadores y eurodiputados.",
                "A los concejales y diputados."

        ));

        task1.add(new ModelQuestions(
                "Â¿De cuÃ¡ntos miembros se compone el Congreso de los diputados",
                "350.",
                "300.",
                "350.",
                "400."
        ));

        task1.add(new ModelQuestions(
                "Durante la segunda mitad del siglo XX, la democracia en EspaÃ±a se instaurÃ³ bajo el reinado de",
                "Juan Carlos I.",
                "Felipe VI.",
                "Juan Carlos I.",
                "Alfonso XIII."
        ));

        task1.add(new ModelQuestions(
                "El nÃºmero de municipios en EspaÃ±a es de aproximadamente",
                "8 000.",
                "8 000.",
                "10 000.",
                "5 000."
        ));

        task1.add(new ModelQuestions(
                "La organizaciÃ³n que defiende y promueve los intereses de los trabajadores se denomina",
                "sindicato.",
                "asociaciÃ³n.",
                "partido.",
                "sindicato."
        ));

        task1.add(new ModelQuestions(
                "Â¿CuÃ¡l de las siguientes personalidades ha sido presidente del Gobierno de EspaÃ±a?",
                "Leopoldo Calvo-Sotelo.",
                "Leopoldo Calvo-Sotelo.",
                "Manuel Fraga.",
                "Josep Tarradellas."

        ));

    }
}
