package com.eb.quizAppSpainsh;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.snackbar.Snackbar;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class RegistrationScreen extends AppCompatActivity {

   private EditText edtEmail,edtPassword;
   private ProgressBar progressBar;
   private RelativeLayout relativeLayout;
    private FirebaseAuth mAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registration_screen);
        mAuth = FirebaseAuth.getInstance();

        relativeLayout=findViewById(R.id.mainRelative);
        edtEmail=findViewById(R.id.signUp_edtEmail);
        edtPassword=findViewById(R.id.signUp_edtPassword);

        progressBar=findViewById(R.id.progress_register);

    }

    public void btn_sign(View view) {
        finish();
    }

    public void btn_Register(View view) {
        String emailAddress = edtEmail.getText().toString().trim();
        String password=edtPassword.getText().toString().trim();
        if (!android.util.Patterns.EMAIL_ADDRESS.matcher(emailAddress).matches()) {
            edtEmail.setError("invalid Email address");
            return;
        }if(password.length() < 6){
            edtPassword.setError("Enter password of minimum 6 letter");
            return;
        }

        registration(emailAddress,password);

    }
    private void registration(String email,String password){
        progressBar.setVisibility(View.VISIBLE);
        mAuth.createUserWithEmailAndPassword(email, password)
                .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {
                            progressBar.setVisibility(View.GONE);

                            FirebaseUser user = mAuth.getCurrentUser();
                            Intent intent=new Intent(RegistrationScreen.this,HomeScreen.class);
                            intent.putExtra("uid",user);
                            startActivity(intent);

                        } else {
                            progressBar.setVisibility(View.GONE);
                            task.addOnFailureListener(new OnFailureListener() {
                                @Override
                                public void onFailure(@NonNull Exception e) {
                                    snackbar( "Authentication failed. "+ e.getMessage());

                                }
                            });

                        }

                    }
                });

     }

    private void snackbar(String message){
        Snackbar snackbar = Snackbar
                .make(relativeLayout, message, Snackbar.LENGTH_LONG);
        snackbar.show();
    }
}