package com.eb.quizAppSpainsh.frament;

import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.eb.quizAppSpainsh.R;
import com.eb.quizAppSpainsh.models.ModelMonthlyProgress;
import com.github.mikephil.charting.animation.Easing;
import com.github.mikephil.charting.charts.BarChart;
import com.github.mikephil.charting.charts.BarLineChartBase;
import com.github.mikephil.charting.charts.PieChart;
import com.github.mikephil.charting.components.AxisBase;
import com.github.mikephil.charting.components.Description;
import com.github.mikephil.charting.components.Legend;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.data.BarData;
import com.github.mikephil.charting.data.BarDataSet;
import com.github.mikephil.charting.data.BarEntry;
import com.github.mikephil.charting.data.PieData;
import com.github.mikephil.charting.data.PieDataSet;
import com.github.mikephil.charting.data.PieEntry;
import com.github.mikephil.charting.formatter.IndexAxisValueFormatter;
import com.github.mikephil.charting.interfaces.datasets.IBarDataSet;
import com.github.mikephil.charting.utils.ColorTemplate;
import com.google.android.material.slider.LabelFormatter;

import java.util.ArrayList;
import java.util.List;

public class StatisticsFragment  extends Fragment   {

    BarChart barChart;
    ArrayList<BarEntry> barEntriesArrayList;
    ArrayList<String > lableName;
    ArrayList<ModelMonthlyProgress> monthlyProgresses = new ArrayList<>();

    PieChart pieChart;
    PieData pieData;
    PieDataSet pieDataSet;
    ArrayList pieEntries;

    List<PieEntry> pieEntryList = new ArrayList<>();

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        View view=inflater.inflate(R.layout.statistics_fragment,container,false);

        return view;
    }
    private void getEntries() {
        pieEntries = new ArrayList<>();
        pieEntries.add(new PieEntry(2f, 0));
        pieEntries.add(new PieEntry(4f, 1));
        pieEntries.add(new PieEntry(6f, 2));
        pieEntries.add(new PieEntry(8f, 3));
        pieEntries.add(new PieEntry(7f, 4));
        pieEntries.add(new PieEntry(3f, 5));
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        barChart =view. findViewById(R.id.barChart);
        pieChart =view.findViewById(R.id.pieChart);
        pieChart = view.findViewById(R.id.pieChart);
        getEntries();

        fillMonthlyProgress();

        barChart();
        pieChart();

    }
    private void pieChart(){
//        pieDataSet = new PieDataSet(pieEntries, "");
//        pieData = new PieData(pieDataSet);
//        pieChart.setData(pieData);
//        pieDataSet.setColors(ColorTemplate.JOYFUL_COLORS);
//        pieDataSet.setSliceSpace(2f);
//        pieDataSet.setValueTextColor(Color.WHITE);
//        pieDataSet.setValueTextSize(10f);
//        pieDataSet.setSliceSpace(5f);

        pieChart.setUsePercentValues(true);
        pieEntryList.add(new PieEntry(10,"Biology"));
        pieEntryList.add(new PieEntry(5,"Chemistry"));
        pieEntryList.add(new PieEntry(7,"English"));
        PieDataSet pieDataSet = new PieDataSet(pieEntryList,"");
        pieData = new PieData(pieDataSet);
        pieChart.setData(pieData);
         Description description = new Description();
        description.setText("");
        pieDataSet.setColors(ColorTemplate.MATERIAL_COLORS);
        pieChart.invalidate();

    }
    private void barChart(){
        barEntriesArrayList = new ArrayList<>();
        lableName  = new ArrayList<>();

        for (int i =0; i < monthlyProgresses.size();i++){
            String month = monthlyProgresses.get(i).getMonth();
            int sales = monthlyProgresses.get(i).getMarks();
            barEntriesArrayList.add(new BarEntry(i,sales));
            lableName.add(month);
        }

        BarDataSet barDataSet = new BarDataSet(barEntriesArrayList,"Monthly Score");
        barDataSet.setColors(ColorTemplate.COLORFUL_COLORS);

        Description description = new Description();
        description.setText("");
        barChart.setDescription(description);
        BarData barData = new BarData(barDataSet);
        barChart.setData(barData);

        XAxis xAxis = barChart.getXAxis();
        xAxis.setValueFormatter(new IndexAxisValueFormatter(lableName));
        xAxis.setDrawGridLines(false);
        xAxis.setDrawAxisLine(false);
        xAxis.setGranularity(1f);
        xAxis.setPosition(XAxis.XAxisPosition.BOTTOM);
        xAxis.setLabelCount(lableName.size());
        //    xAxis.setLabelRotationAngle(0);
        barChart.animateY(2000);
        barChart.invalidate();
    }
    private void fillMonthlyProgress(){
        monthlyProgresses.clear();
        monthlyProgresses.add(new ModelMonthlyProgress("Jan",100));
        monthlyProgresses.add(new ModelMonthlyProgress("Feb",50));
        monthlyProgresses.add(new ModelMonthlyProgress("Mar",120));
        monthlyProgresses.add(new ModelMonthlyProgress("Apr",130));
        monthlyProgresses.add(new ModelMonthlyProgress("May",90));
        monthlyProgresses.add(new ModelMonthlyProgress("June",190));
        monthlyProgresses.add(new ModelMonthlyProgress("July",130));
        monthlyProgresses.add(new ModelMonthlyProgress("Aug",30));
        monthlyProgresses.add(new ModelMonthlyProgress("Sep",200));
        monthlyProgresses.add(new ModelMonthlyProgress("Oct",250));
        monthlyProgresses.add(new ModelMonthlyProgress("Nov",150));
        monthlyProgresses.add(new ModelMonthlyProgress("Dec",220));
    }
}
