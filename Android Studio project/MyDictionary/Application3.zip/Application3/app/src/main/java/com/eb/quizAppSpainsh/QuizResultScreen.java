package com.eb.quizAppSpainsh;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import java.util.HashMap;

public class QuizResultScreen extends AppCompatActivity {

    int totalQuestions,correct,wrong;
    String quizName;
    TextView txtTotalQuestion,txtCorrect,txtWrong,txtPersentage;
    int persentage;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_quiz_result_screen);

        txtTotalQuestion=findViewById(R.id.txt_totalQuestions);
        txtCorrect=findViewById(R.id.txt_correctQuestions);
        txtWrong=findViewById(R.id.txt_wrongQuestions);
        txtPersentage=findViewById(R.id.txt_persentage);

        totalQuestions=getIntent().getIntExtra("totalQuestion",0);
        txtTotalQuestion.setText(String.valueOf(totalQuestions));

        correct=getIntent().getIntExtra("correct",0);
        txtCorrect.setText(String.valueOf(correct));

        wrong=getIntent().getIntExtra("wrong",0);
        txtWrong.setText(String.valueOf(wrong));

        quizName=getIntent().getStringExtra("quizName");

        Intent intent = getIntent();
        HashMap<String, String> hashMap = (HashMap<String, String>) intent.getSerializableExtra("hashMapWrongQues");
        persentage=correct*100/totalQuestions;
        txtPersentage.setText(String.valueOf(persentage) +"%");


    }


    public void btnBack(View view) {
        finish();
    }

}