package com.eb.quizAppSpainsh.RoomDatabase;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;

@Dao
public interface DAO {

   @Insert(onConflict = OnConflictStrategy.REPLACE)
   public void questionInsertion(Questions questions);

   @Insert
   public void scoreInsertion(Score score);

}
