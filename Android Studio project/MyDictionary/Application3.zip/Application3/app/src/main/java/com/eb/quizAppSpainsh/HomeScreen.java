package com.eb.quizAppSpainsh;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.MenuItem;

import com.eb.quizAppSpainsh.frament.HelpFragment;
import com.eb.quizAppSpainsh.frament.MenuFragment;
import com.eb.quizAppSpainsh.frament.QuestionsByTopicsFragment;
import com.eb.quizAppSpainsh.frament.QuizCategoriesFragment;
import com.eb.quizAppSpainsh.frament.StatisticsFragment;
import com.google.android.material.bottomnavigation.BottomNavigationView;

public class HomeScreen extends AppCompatActivity {

    BottomNavigationView bottomNavigation;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home_screen);
        bottomNavigation = findViewById(R.id.bottom_navigation);

        loadFragment(new QuizCategoriesFragment());


        bottomNavigation.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @SuppressLint("NonConstantResourceId")
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                Fragment fragment = null;
                switch (item.getItemId()){

                    case R.id.home:
                        fragment=new QuizCategoriesFragment();
                        break;
                    case R.id.statistics:
                        fragment=new StatisticsFragment();
                        break;
                    case R.id.question:
                        fragment=new QuestionsByTopicsFragment();
                        break;
                    case R.id.help:
                        fragment=new HelpFragment();
                        break;
                    case R.id.menu:
                        fragment=new MenuFragment();
                        break;
                }

                return loadFragment(fragment);
            }
        });

    }
    private boolean loadFragment(Fragment fragment) {
        //switching fragment
        if (fragment != null) {
            getSupportFragmentManager()
                    .beginTransaction()
                    .replace(R.id.frame_container, fragment)
                    .commit();
            return true;
        }
        return false;
    }
}