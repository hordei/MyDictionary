package com.eb.quizAppSpainsh.RoomDatabase;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "scores")
public class Score {
    @PrimaryKey(autoGenerate = true)
    int scoreId;
    int totalScore;
    int obtaiedScore;

    String topicName;

}
